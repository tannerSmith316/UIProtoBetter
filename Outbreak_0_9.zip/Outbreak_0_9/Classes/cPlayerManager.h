//
//  cPlayerManager.h
//  Outbreak_0_9
//
//  Created by McKenzie Kurtz on 2/29/12.
//  Copyright 2012 Oregon Institute of Technology. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface cPlayerManager : NSObject {

	
}

- (BOOL)AttemptAutoLogin;
- (void)Login;
- (void)Logout;

@end

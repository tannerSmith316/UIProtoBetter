//
//  MainMenuViewController.h
//  UIProtoBetter
//
//  Created by McKenzie Kurtz on 10/29/11.
//  Copyright 2011 Oregon Institute of Technology. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MainMenuViewController : UIViewController {

}
//Button Pushes create view controller and push it onto stack
-(IBAction)pressCreation;
-(IBAction)pressOffline;
-(IBAction)pressOnline;

@end

//
//  CreationMenuViewController.h
//  UIProtoBetter
//
//  Created by McKenzie Kurtz on 10/31/11.
//  Copyright 2011 Oregon Institute of Technology. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreationMenuViewController : UIViewController {
	
}

-(void)popViewToSelf;
-(IBAction)pressCreate;
//-(IBAction)pressSelect;

@end

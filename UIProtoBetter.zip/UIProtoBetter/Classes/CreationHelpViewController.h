//
//  CreationHelpViewController.h
//  UIProtoBetter
//
//  Created by McKenzie Kurtz on 11/5/11.
//  Copyright 2011 Oregon Institute of Technology. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CreationHelpViewController : UIViewController {

}

-(IBAction)pressDone;

@end

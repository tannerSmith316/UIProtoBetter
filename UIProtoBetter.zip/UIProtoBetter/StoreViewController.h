//
//  StoreViewController.h
//  UIProtoBetter
//
//  Created by McKenzie Kurtz on 10/29/11.
//  Copyright 2011 Oregon Institute of Technology. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface StoreViewController : UIViewController {
	IBOutlet UILabel *cashLabel;
	IBOutlet UILabel *failedLabel;
	int cash;
}

-(IBAction)buyPotion;
@property(nonatomic, retain)IBOutlet UILabel *failedLabel;
@property(nonatomic, retain)IBOutlet UILabel *cashLabel;

@end

//
//  OfflineModeViewController.h
//  UIProtoBetter
//
//  Created by McKenzie Kurtz on 10/29/11.
//  Copyright 2011 Oregon Institute of Technology. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface OfflineModeViewController : UIViewController {
	IBOutlet UIButton *healButton;
}

@property(nonatomic, retain)IBOutlet UIButton *healButton;

-(IBAction)pressHeal;
-(IBAction)pressStash;
-(IBAction)pressStore;
@end

//
//  StashViewController.h
//  UIProtoBetter
//
//  Created by McKenzie Kurtz on 10/29/11.
//  Copyright 2011 Oregon Institute of Technology. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface StashViewController : UIViewController {
	int potions;
	IBOutlet UILabel *numPotionLabel;
	IBOutlet UILabel *failedPotion;
}

-(IBAction)usePotion;

@property(nonatomic, retain)IBOutlet UILabel *failedPotion;
@property(nonatomic, retain)IBOutlet UILabel *numPotionLabel;

@end
